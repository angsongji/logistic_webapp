package com.uteexpress.entity;

public enum OrderStatus {

    CHO_GIAO, DANG_GIAO, HOAN_THANH, THAT_BAI, HUY

}