package com.uteexpress.entity;

public enum RoleType {
    ROLE_ADMIN,            
    ROLE_WAREHOUSE_STAFF,  
    ROLE_SHIPPER,         
    ROLE_CUSTOMER,         
    ROLE_ACCOUNTANT       
}
